<h2>My Profile:</h2>

<table style="width:100%">
  <tr>
    <th>Name:</th>
    <td><?php echo e($data->name); ?></td>
  </tr>
  <tr>
    <th>Designation:</th>
    <td><?php echo e($data->designation); ?></td>
  </tr>
  <tr>
    <th>Image:</th>
    <td><img src="<?php echo e(asset('image/'.$data->image)); ?>" width="150" height="100" style="margin-top:40px; border-radius:100%;"></td>
  </tr>
</table><?php /**PATH C:\Users\Code For Solutions\OBC-ALL-INDIA\resources\views/Admin/master/team/show.blade.php ENDPATH**/ ?>