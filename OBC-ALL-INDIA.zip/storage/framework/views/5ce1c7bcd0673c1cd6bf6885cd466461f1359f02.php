


<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    .slide_img{
    width: 60px;
    height: 60;
    border-radius: 50%;
    }
</style>
<div class="comtainer">
    <div class="row">
        <div class="col-xl-12 text-end">
            <a class="btn btn-primary" style="background-color:green!important;" href="<?php echo e(route('settings.index')); ?>">Back</a>
        </div>
    </div>
    <h1 class="mb-3">Slider</h1>
    <div class="row">
        <div class="col-md-6">
           <div class="card">
                <div class="card-header">
                    <h4 class="card-title"> Edit Form</h4>
                </div>
                <div class="card-body" style="text-align: left!important;">
                    <form method="post" action="<?php echo e(route('settings.update',$data->id)); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group">
                            <label for="exampleInputEmail1" class="form-label">Title</label>
                            <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
                            <input type="text" name="title" value="<?php echo e($data->title); ?>" class="form-control" id="exampleInputEmail1" placeholder="Title">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1" class="form-label">Image</label>
                            <input type="file" name="image" class="form-control" id="exampleInputPassword1" placeholder="file">
                        </div>
                        <button  class="btn btn-primary mt-2 mb-0">Update</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                  <h5 class="card-title">slider image</h5>
                </div>
                <div class="card-body">
                    <img src="<?php echo e(asset('image/'.$data->image)); ?>" alt="" height="227">
                </div>
            </div>
        </div>
    </div>
    <!-- End Row -->
</div>
<br>

<?php echo $__env->make('Admin.partial.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.partial.sidenavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.partial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Code For Solutions\OBC-ALL-INDIA\resources\views/Admin/setting/slider/edit.blade.php ENDPATH**/ ?>