



<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">
  <div class="row">
    <div class="col-md-12">
    <div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Users Management</h2>
        </div>
        <div class="pull-right">
            <a href="<?php echo e(route('export')); ?>" class="btn btn-primary">Export to Excel/CSV</a>
            <a class="btn btn-success" href="<?php echo e(route('users.create')); ?>"> Create New User</a>
            <a class="btn btn-primary" style="background-color:green!important;" href="<?php echo e(route('members.create')); ?>">Registration Member's</a>
        </div>
    </div>
</div>

<table class="table table-striped">
 <tr>
   <th>No</th>
   <th>Name</th>
   <th>Email</th>
   <th>Created By</th>
   <th>Roles</th>
   <th>Status</th>
   <th width="280px">Action</th>
 </tr>
 <?php $i = 1; ?>

    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <?php if($user_id != $user->roles->id  && $user_id <= $user->roles->id && $userId == $user->userscreate->id): ?>
          <tr>
            <td><?php echo e($i++); ?></td>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td><?php echo e($user->userscreate ? $user->userscreate->name : ''); ?></td>
            <td><?php echo e($user->roles ? $user->roles->name  : ''); ?></td>
            <td>
            <?php if(in_array("super_admin", Auth::user()->roles->toArray())): ?>
                <?php if($user->status == 1): ?>
                  <a href="<?php echo e(route('admin.approve', $user->id)); ?>" class="btn btn-success btn-sm">Approve</a>
                  <?php else: ?>
                  <a href="<?php echo e(route('admin.approve', $user->id)); ?>" class="btn btn-danger btn-sm">UnApprove</a>
                <?php endif; ?>
          <?php endif; ?>
            </td>
            <td>
            <form action="<?php echo e(route('users.destroy',$user->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <a class="btn btn-warning btn-sm" href="<?php echo e(route('users.show',$user->id)); ?>">Show</a>
                <a class="btn btn-success btn-sm" href="<?php echo e(route('users.edit',$user->id)); ?>">Edit</a>
                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
            </form>
            </td>
          </tr>
       <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td colspan="12" align="left" style="text-decoration:none;">
      <?php echo e($data->links()); ?>

      </td>
    </tr>
</table>
    
    </div>
    
  </div>
</div>
<?php echo $__env->make('Admin.partial.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.partial.sidenavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.partial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Code For Solutions\OBC-ALL-INDIA\resources\views/users/index.blade.php ENDPATH**/ ?>