<footer class="footer">
    <div class="container">
        <div class="row align-items-center flex-row-reverse">
            <div class="col-md-12 col-sm-12 text-center">
            <p>© 2021 All rights reserved by OBCALLINDIA.COM.</p>
            </div>
        </div>
    </div>
</footer>
</div>

<a href="#top" id="back-to-top"><i class="fa fa-angle-up"></i></a>


<!-- BACK-TO-TOP -->
<a href="#top" id="back-to-top"><i class="fa fa-angle-up"></i></a>

<!-- JQUERY JS -->
<script src="<?php echo e(asset('plugins/jquery/jquery.min.js')); ?>"></script>

<!-- BOOTSTRAP JS -->
<script src="<?php echo e(asset('plugins/bootstrap/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>

<!-- INPUT MASK JS-->
<script src="<?php echo e(asset('plugins/input-mask/jquery.mask.min.js')); ?>"></script>

<!-- SIDEBAR JS -->
<script src="<?php echo e(asset('plugins/sidebar/sidebar.js')); ?>"></script>

<!-- SIDE-MENU JS-->
<script src="<?php echo e(asset('plugins/sidemenu/sidemenu2.js')); ?>"></script>

<!-- Perfect SCROLLBAR JS-->
<script src="<?php echo e(asset('plugins/p-scroll/perfect-scrollbar.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/p-scroll/pscroll.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/p-scroll/pscroll-1.js')); ?>"></script>

<!-- CHARTJS CHART JS-->
<script src="<?php echo e(asset('plugins/chart/Chart.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/chart/utils.js')); ?>"></script>

<!-- PIETY CHART JS-->
<script src="<?php echo e(asset('plugins/peitychart/jquery.peity.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/peitychart/peitychart.init.js')); ?>"></script>

<!-- INTERNAL SELECT2 JS -->
<script src="<?php echo e(asset('plugins/select2/select2.full.min.js')); ?>"></script>

<!-- INTERNAL Data tables js-->
<!-- <script src="<?php echo e(asset('plugins/datatable/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatable/js/dataTables.bootstrap5.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatable/dataTables.responsive.min.js')); ?>"></script> -->

<!-- DATA TABLE JS-->
        <script src="<?php echo e(asset('plugins/datatable/js/jquery.dataTables.min.js')); ?>"></script>
		<script src="<?php echo e(asset('plugins/datatable/js/dataTables.bootstrap5.js')); ?>"></script>
		<script src="<?php echo e(asset('plugins/datatable/js/dataTables.buttons.min.js')); ?>"></script>
		<script src="<?php echo e(asset('plugins/datatable/js/buttons.bootstrap5.min.js')); ?>"></script>
		<script src="<?php echo e(asset('plugins/datatable/js/jszip.min.js')); ?>"></script>
		<script src="<?php echo e(asset('plugins/datatable/pdfmake/pdfmake.min.js')); ?>"></script>
		<script src="<?php echo e(asset('plugins/datatable/pdfmake/vfs_fonts.js')); ?>"></script>
		<script src="<?php echo e(asset('plugins/datatable/js/buttons.html5.min.js')); ?>"></script>
		<script src="<?php echo e(asset('plugins/datatable/js/buttons.print.min.js')); ?>"></script>
		<script src="<?php echo e(asset('plugins/datatable/js/buttons.colVis.min.js')); ?>"></script>
		<script src="<?php echo e(asset('plugins/datatable/dataTables.responsive.min.js')); ?>"></script>
		<script src="<?php echo e(asset('plugins/datatable/responsive.bootstrap5.min.js')); ?>"></script>
		<script src="<?php echo e(asset('js/table-data.js')); ?>"></script>

<!-- ECHART JS-->
<script src="<?php echo e(asset('plugins/echarts/echarts.js')); ?>"></script>

<!-- APEXCHART JS -->
<script src="<?php echo e(asset('js/apexcharts.js')); ?>"></script>

<!-- INDEX JS -->
<script src="<?php echo e(asset('js/index1.js')); ?>"></script>

<!-- CUSTOM JS-->
<script src="<?php echo e(asset('js/custom.js')); ?>"></script>

<!-- Switcher js -->
<script src="<?php echo e(asset('switcher/js/switcher.js')); ?>"></script>


</body>

<!-- Mirrored from laravel.spruko.com/zanex/ltr/index1 by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Mar 2022 09:28:13 GMT -->
</html><?php /**PATH C:\Users\Code For Solutions\OBC-ALL-INDIA\resources\views/Admin/partial/footer.blade.php ENDPATH**/ ?>