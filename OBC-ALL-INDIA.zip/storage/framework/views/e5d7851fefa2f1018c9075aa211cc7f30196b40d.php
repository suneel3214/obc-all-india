<p class="card-text"><?php echo $data->description; ?></p>
<?php /**PATH C:\Users\Code For Solutions\OBC-ALL-INDIA\resources\views/Admin/master/gallery/show.blade.php ENDPATH**/ ?>