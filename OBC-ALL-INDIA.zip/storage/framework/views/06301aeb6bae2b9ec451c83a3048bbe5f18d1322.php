<h2>My Profile:</h2>

<table style="width:100%">
  <tr>
    <th>First-Name:</th>
    <td><?php echo e($member->fname); ?></td>
  </tr>
  <tr>
    <th>Last-Name:</th>
    <td><?php echo e($member->lname); ?></td>
  </tr>
  <tr>
    <th>Email:</th>
    <td><?php echo e($member->email); ?></td>
  </tr>
  <tr>
    <th>Mobile:</th>
    <td><?php echo e($member->mobile); ?></td>
  </tr>
  <tr>
    <th>Category:</th>
    <td><?php echo e($member->category); ?></td>
  </tr>
  <tr>
    <th>Qualification:</th>
    <td><?php echo e($member->qualification); ?></td>
  </tr>
  <tr>
    <th>Work:</th>
    <td><?php echo e($member->work); ?></td>
  </tr>
  <tr>
    <th>Aadhar Number:</th>
    <td><?php echo e($member->aadhar_no); ?></td>
  </tr>
  <tr>
    <th>Pan Card Number:</th>
    <td><?php echo e($member->pan_no); ?></td>
  </tr>
  <tr>
    <th>State:</th>
    <td><?php echo e($member->states->name); ?></td>
  </tr>
  <tr>
    <th>City:</th>
    <td><?php echo e($member->cities->name); ?></td>
  </tr>
  <tr>
    <th>Created By:</th>
    <td><?php echo e($member->membersuser ? $member->membersuser->name  : ''); ?></td>
  </tr>
  <tr>
    <th>Tehshil:</th>
    <td><?php echo e($member->teshil); ?></td>
  </tr>
  <tr>
    <th>Punchayat:</th>
    <td><?php echo e($member->panchayat); ?></td>
  </tr>
  <tr>
    <th>Village:</th>
    <td><?php echo e($member->village); ?></td>
  </tr>
  <tr>
    <th>Pin Code:</th>
    <td><?php echo e($member->picode); ?></td>
  </tr>
  <tr>
    <th>Comments:</th>
    <td><?php echo e($member->comment); ?></td>
  </tr>
  <tr>
    <th>ID Proof:</th>
    <td><img src="<?php echo e(asset('image/'.$member->id_proof)); ?>" alt="$member->id_proof" width="150" height="100"></td>
  </tr>
</table><?php /**PATH C:\Users\Code For Solutions\OBC-ALL-INDIA\resources\views/member/show.blade.php ENDPATH**/ ?>