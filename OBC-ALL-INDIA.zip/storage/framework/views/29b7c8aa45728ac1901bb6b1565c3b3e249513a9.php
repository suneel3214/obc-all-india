



<?php $__env->startSection('content'); ?>



<div class="container">
  <div class="row">
    <div class="col-md-12">
    <div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2><?php echo e($title); ?></h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-success" href="<?php echo e(route('users.create')); ?>"> Create New User</a>
            <a class="btn btn-primary" style="background-color:green!important;" href="<?php echo e(route('members.create')); ?>">Registration Member's</a>
        </div>
    </div>
</div>


<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
  <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>


<table class="table table-striped">
 <tr>
   <th>No</th>
   <th>Name</th>
   <th>Email</th>
   <th>Created By</th>
   <th>Roles</th>
   <th width="280px">Action</th>
   <?php $i = 1; ?>
 </tr>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($user_id != $user->roles->id  && $user_id <= $user->roles->id && $userId == $user->userscreate->id): ?>
          <tr>
            <td><?php echo e($i ++); ?></td>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td><?php echo e($user->userscreate ? $user->userscreate->name : ''); ?></td>
            <td><?php echo e($user->roles ? $user->roles->name  : ''); ?></td>
            <td>
              <a class="btn btn-warning btn-sm" href="<?php echo e(route('users.show',$user->id)); ?>">Show</a>
              <a class="btn btn-success btn-sm" href="<?php echo e(route('users.edit',$user->id)); ?>">Edit</a>
                <?php echo Form::open(['method' => 'DELETE','route' => ['users.destroy', $user->id],'style'=>'display:inline']); ?>

                    <?php echo Form::submit('Delete', ['class' => 'btn btn-danger btn-sm']); ?>

                <?php echo Form::close(); ?>

            </td>
          </tr>
       <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
    </div>
  </div>
</div>
<?php echo $__env->make('Admin.partial.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.partial.sidenavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.partial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Code For Solutions\OBC-ALL-INDIA\resources\views/users/stateadmin.blade.php ENDPATH**/ ?>