<p class="card-text">{!! $data->description !!}</p>
