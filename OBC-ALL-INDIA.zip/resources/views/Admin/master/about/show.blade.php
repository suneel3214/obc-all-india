<h2>{{$data->heading}}</h2>
<p>{!!$data->description!!}</p>